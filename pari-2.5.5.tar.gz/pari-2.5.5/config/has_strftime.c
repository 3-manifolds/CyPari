#include <time.h>
main(){ struct tm *x; strftime("",1,"",x);}
