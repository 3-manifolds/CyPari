#include <unistd.h>
main(){ isatty(0); }
