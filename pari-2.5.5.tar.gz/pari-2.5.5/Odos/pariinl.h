/*   This file contains declarations/definitions of functions that
 *   _can_ be inlined.
 */
/* $Id$ */

#ifndef WINCE
#  include "../src/kernel/ix86/level0.h"
#else
#  include "../src/kernel/none/level0.h"
#endif

#include "../src/kernel/none/level1.h"

